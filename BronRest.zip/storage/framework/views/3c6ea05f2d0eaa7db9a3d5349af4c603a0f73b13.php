

<?php $__env->startSection('title', 'Create Restauranat'); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/css/uploade-file.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">
                Создать  <?php echo e(request()->route('id') ? '' : 'Главный'); ?> ресторан
            </p>
            <form action="<?php echo e(route('createRestaurant',request()->route('id'))); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group mb-3">
                    <label >Имя</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Имя" name="name" value="<?php echo e(old('name')); ?>">

                    
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="form-group mb-3">
                    <label >Номер телефона</label>
                    <input type="number" class="form-control <?php echo e($errors->has('phone_number') ? 'is-invalid' : ''); ?>" placeholder="Номер телефона" name="phone_number" value="<?php echo e(old('phone_number')); ?>">
                    
                    <?php if($errors->has('phone_number')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('phone_number')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label>Описание</label>
                        <textarea class="form-control <?php echo e($errors->has('desc') ? 'is-invalid' : ''); ?>" rows="3" placeholder="Описание ..." name="desc">
                            <?php echo e(old('desc') ? old('desc') : ''); ?>

                        </textarea>
                        <?php if($errors->has('desc')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('desc')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                </div>

                <?php if(!request()->route('id')): ?>
                    <div class="form-group">
                        <label for="exampleInputFile">Выберите логотип ресторана</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="exampleInputFile" name="logo">
                                    <label class="custom-file-label" for="exampleInputFile">Выберите файл</label>
                                </div>
                                <div class="input-group-append">
                                    <span class="input-group-text">Загрузить</span>
                                </div>
                            </div>
                    </div>
                <?php endif; ?>


                <?php if(request()->route('id')): ?>
                <div class="row form-group">
                    <input type="text" name="latit" class="latit_inp"  hidden>
                    <input type="text" name="longit" class="longit_inp"  hidden>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-check-label">Категории кухонь</label>
                            <?php $__currentLoopData = $kitchenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input checkbox_fuc" type="checkbox" name="kitchen_cats[<?php echo e($data['id']); ?>]">
                                    <label class="form-check-label"><?php echo e($data['name']); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-3">
                <label><?php echo e($day->day); ?></label>
                <input type="time" class="form-control work-days-start" name="<?php echo e($day->id . '_start'); ?>">
                <input type="time" class="form-control work-days-end" name="<?php echo e($day->id . '_end'); ?>">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <br>

                </div>
                <div class="form-group">

                    <div class="form-group card-body">
                        <label for="exampleInputFile">Выберите изображения</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input uploade-file" id="exampleInputFile" name="images[]" multiple>
                                    <label class="custom-file-label" for="exampleInputFile">Выберите файл</label>
                                </div>
                                <div class="input-group-append">
                                    <span class="input-group-text">Загрузить</span>
                                </div>
                            </div>
                    </div>

                    <div class="col">
                        <div id="map" style="width: 100%; height: 400px"></div>
                    </div>
                <?php endif; ?>

                <div class="cont-uploaded-images"></div>

                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block">Создать</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://api-maps.yandex.ru/2.1/?apikey=a750744b-d04d-479b-9650-d81ed44bfffc&lang=ru_RU" type="text/javascript">
</script>
<script src="<?php echo e(asset('assets/js/uploade_file.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/work_days.js')); ?>"></script>

<?php if(request()->route('id')): ?>
        <script src="<?php echo e(mix ('js/app.js')); ?>"></script>


    <script type="text/javascript">

    $('.checkbox_fuc').on('change', function (e) {
    if ($('.checkbox_fuc:checked').length > 3) {
        $(this).prop('checked', false);
        alert("allowed only 3");
    }
});
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/yandex_map.js')); ?>"> 
    </script>
    <script>
        start()    
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/restaurant/create.blade.php ENDPATH**/ ?>
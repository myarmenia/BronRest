<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>
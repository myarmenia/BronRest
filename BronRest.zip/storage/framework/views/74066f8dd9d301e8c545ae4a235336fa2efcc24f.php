

<?php $__env->startSection('title', 'Create Restauranat'); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/css/restaurant.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
       <a type="button" class="btn btn-block btn-primary" href="<?php echo e(route('createMainRestaurantPage',request()->route('id') ?? null)); ?>">
        Создать <?php echo e(request()->route('id') ? '' : 'Главный'); ?>  ресторан
        
       </a>
<br>
<div class="d-flex flex-wrap justify-content-between cont-restaurant">
<?php if(isset($data)): ?>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card p-3">
            <div class="card-head d-flex w-100 my-2">
                <div class="text-bold"> <?php echo e(++$i); ?> </div>
                <div class="text-center w-100">
                    <h4 class="card-title w-100 "> <?php echo e($dat['name'] ?? null); ?> </h4>
                </div>
            </div>
            <hr width="100%">

            <div class="h-100 d-flex flex-column justify-content-between">
                <div class="">
                    <?php if(!request()->route('id')): ?>
                        <?php if(count($dat['images'])>0): ?>
                            <?php $__currentLoopData = $dat['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col">
                                <img class="card-img-top img-thumbnail" src="<?php echo e(route('getFile',['path' => $img['path'] ?: null])); ?>" alt="Card image cap" style="width: 100px">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="col">
                            <img class="card-img-top img-thumbnail" src="<?php echo e(route('getFile',['path' => 'public/restaurant/xe8E1wk503KkgxvNLnH0QCPG1M9jHgcYIQyTOSGU.png'])); ?>" alt="Card image cap" style="width: 100px">
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>

                </div>
                <div class="my-2">
                    <p class="card-text">
                        <?php echo e($dat['desc'] ?? null); ?>

                    </p>
                </div>
                <div class="">
                    <?php if(!request()->route('id')): ?>
                        <a href="<?php echo e(route('getRestaurant',$dat['id'])); ?>" class="btn btn-primary"> Показывать </a>
                    <?php endif; ?>
                    <a class="btn btn-secondary" href="<?php echo e(route('editRestaurant',$dat['id'])); ?>">
                        Редактировать
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class='w-100 text-center'>Нет информации</div>
<?php endif; ?>
</div>
   <?php echo e($data->links()); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/restaurant/index.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>
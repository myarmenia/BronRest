

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left mt-3">
                <h2>
                    Заказы пользователей
                </h2>
            </div>
        </div>
    </div>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-primary">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <table class="table table-bordered mt-3">
        <tr>
            <th>
                Электронная почта пользователя
            </th>
            <th>
                Время подхода
            </th>
            <th>
                Число людей
            </th>

            <th width="280px">Действие</th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->user['email']); ?></td>
                <td><?php echo e($data->coming_date); ?></td>
                <td><?php echo e($data->people_nums); ?></td>
                <td>
                        <a href="<?php echo e(route('userShow',['id' => $data->id])); ?>" class="btn btn-primary">
                            Редактировать
                        </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/user_orders/index.blade.php ENDPATH**/ ?>
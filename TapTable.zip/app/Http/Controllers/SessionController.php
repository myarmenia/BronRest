<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SessionController extends Controller
{
    public function accessSessionData(Request $request) {

     }
     public function storeSessionData(Request $request) {

     }
     public function deleteSessionData(Request $request) {

     }
}

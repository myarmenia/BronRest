<?php echo e($slot); ?>

<?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
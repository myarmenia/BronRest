<?php $__env->startSection('title', 'Create Restauranat'); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/css/restaurant.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
       <!-- <a type="button" class="btn btn-block btn-primary" href="<?php echo e(route('createMainRestaurantPage',request()->route('id') ?? null)); ?>">
        Создать <?php echo e(request()->route('id') ? '' : 'Главный'); ?>  ресторан
        
       </a>
<br>
<div class="d-flex flex-wrap justify-content-between cont-restaurant">
<?php if(isset($data)): ?>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card p-3">
            <div class="card-head d-flex w-100 my-2">
                <div class="text-bold"> <?php echo e(++$i); ?> </div>
                <div class="text-center w-100">
                    <h4 class="card-title w-100 "> <?php echo e($dat['name'] ?? null); ?> </h4>
                </div>
            </div>
            <hr width="100%">

            <div class="h-100 d-flex flex-column justify-content-between">
                <div class="">
                    <?php if(!request()->route('id')): ?>
                        <?php if(count($dat['images'])>0): ?>
                            <?php $__currentLoopData = $dat['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col">
                                <img class="card-img-top img-thumbnail" src="<?php echo e(route('getFile',['path' => $img['path'] ?: null])); ?>" alt="Card image cap" style="width: 100px">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="col">
                            <img class="card-img-top img-thumbnail" src="<?php echo e(route('getFile',['path' => 'public/restaurant/xe8E1wk503KkgxvNLnH0QCPG1M9jHgcYIQyTOSGU.png'])); ?>" alt="Card image cap" style="width: 100px">
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>

                </div>
                <div class="my-2">
                    <p class="card-text">
                        <?php echo e($dat['desc'] ?? null); ?>

                    </p>
                </div>
                <div class="">
                    <?php if(!request()->route('id')): ?>
                        <a href="<?php echo e(route('getRestaurant',$dat['id'])); ?>" class="btn btn-primary"> Показывать </a>
                    <?php endif; ?>
                    <a class="btn btn-secondary" href="<?php echo e(route('editRestaurant',$dat['id'])); ?>">
                        Редактировать
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class='w-100 text-center'>Нет информации</div>
<?php endif; ?>
</div>
   <?php echo e($data->links()); ?> -->

<!-- /////////////////////////////////////////////////// -->

   <div class="container">
    <a href="<?php echo e(route('createMainRestaurantPage',request()->route('id') ?? null)); ?>">
        <div class="amount">
            <div class="circle">+</div>
            <span> <?php echo e(request()->route('id') ? '' : 'Добавить филиал'); ?></span>
            
        </div>
        </a>
   <?php if(isset($data)): ?>
   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="section">
            <div class="name">
                <h2 class="name_title"><?php echo e($dat['name'] ?? null); ?></h2>

            </div>
            <!-- <p class="responsible"><a href="#"> Ответственное лицо</a></p> -->
            <div class="name_item">
                <!-- <p><a href="#">Направление кухни</a></p> -->
                <!-- <p><a href="#">Тип заведения</a></p> -->
                <p><a href="#"><?php echo e($dat['desc'] ?? null); ?></a></p>
                <div class="geolocation">
                    <img src="<?php echo e(asset('assets/images/Group.png')); ?>">
                    <p><a href="#"><?php echo e($dat['address'] ?? null); ?></a></p>
                </div>
                <p><a href="#"><?php echo e($dat['phone_number'] ?? null); ?></a></p>
                <!-- <div class="working_time">
                    <p class="time_title">Время работы</p>
                    <div class="time">
                        <div class="time_opn_off">
                            <img src="<?php echo e(asset('assets/images/clock.png')); ?>">
                            <span>10:20-23:00</span>
                        </div>
                        <span class="daily">Ежедневно</span>
                    </div>
                </div> -->
            </div>
            <div class="time_img">

                <div class="time_photo">
                <?php if(!request()->route('id')): ?>
                    <?php if(count($dat['images'])>0): ?>
                        <?php $__currentLoopData = $dat['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <img src="<?php echo e(route('getFile',['path' => $img['path'] ?: null])); ?>">
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <img src="<?php echo e(route('getFile',['path' => 'public/restaurant/xe8E1wk503KkgxvNLnH0QCPG1M9jHgcYIQyTOSGU.png'])); ?>" alt="">
                    <?php endif; ?>
                <?php endif; ?>
                </div>

            </div>
            <div class="">
                    <?php if(!request()->route('id')): ?>
                        <a href="<?php echo e(route('getRestaurant',$dat['id'])); ?>">
                            <img src="<?php echo e(asset('assets/images/Group_1134.png')); ?>" alt="pan"> Показывать
                        </a>
                    <?php endif; ?>
                   <br>

                    <a href="<?php echo e(route('editRestaurant',$dat['id'])); ?>">
                        <img src="<?php echo e(asset('assets/images/Group_1134.png')); ?>" alt="pan">Редактировать
                        <?php if(request()->route('id')): ?>
                           и добавить меню
                         <?php endif; ?>
                    </a>
            </div>
            <br>
            <!-- <a href="app.html">
                <div class="amount">
                    <div class="circle">+</div>
                    <span>Добавить филиал</span>
                </div>
            </a> -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class='w-100 text-center'>Нет информации</div>
        <?php endif; ?>
    </div>
    <?php echo e($data->links()); ?>

    <!-- <div class="profile">
        <a href="#">
            <a href="#" class="profile_title">Профиль</a>
        </a>
        <hr>
        <a href="#" class="profile_text">Регистрация ресторана</a>
        <a href="#" class="profile_text">Меню</a>
        <a href="#" class="profile_text">Внесение посадочных мест</a>
    </div> -->

    <script>

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/restaurant/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Create Restauranat'); ?>
<?php $__env->startSection('css'); ?>

    <link href="<?php echo e(asset('assets/css/accordion.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                </div>
                <div class="pull-right mb-2">
                    <a class="btn btn-primary" onClick="add()" href="javascript:void(0)"> Создать </a>
                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <table class="table table-bordered" id="ajax-crud-datatable">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Название еды</th>
                    <th>Цена</th>
                    <th>Категория</th>
                    <th>Created at</th>
                    <th>Действие</th>
                </tr>
                </thead>
            </table>
        </div>
    </div> -->

    <!-- boostrap company model -->
    <div class="modal fade" id="company-modal" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="CompanyModal"></h4>
                </div>
                <div class="modal-body">
                    <form action="javascript:void(0)" id="CompanyForm" name="CompanyForm" class="form-horizontal" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="id">
                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Название еды</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Название еды" maxlength="50" required="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Цена</label>
                            <div class="col-sm-12">
                                <input pattern="^\d*(\.\d{0,2})?$" class="form-control" id="price" name="price" placeholder="Enter Price" required="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"> Описание</label>
                            <div class="">
                                <textarea name="desc" id="" class="w-100" rows="10"></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="exampleInputFile" name="img">
                                    <label class="custom-file-label" for="exampleInputFile">Выберите изображение</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Категория</label>
                            <?php if($categories): ?>
                                <input class="form-control" list="datalistOptions" id="exampleDataList" name="category">
                                <datalist id="datalistOptions">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat['name']); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            <?php endif; ?>
                        </div>
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-primary" id="btn-save">Сохранить изменения</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <!-- end bootstrap model -->
    <div class="container">
        <div class="accordion">
            <a class="btn btn1" onClick="add()" href="javascript:void(0)"> Создать </a><br><br>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion_item ">
                <div class="accordion_title ">
                    <div class="accordion_titimg " >
                        <h1><?php echo e($dat->name); ?></h1>
                        <a> <img src="<?php echo e(asset('assets/images/Group_1134.png')); ?>"></a>
                    </div>

                    <img src="<?php echo e(asset('assets/images/Vector-65.png')); ?>">
                </div>
                <?php $__currentLoopData = $dat->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion_answer ">
                    <div class="price ">
                        <div class="price_box ">
                            <div class="price_img ">
                            <img src="<?php echo e(route('getFile',['path' => $menu->img])); ?>">
                            </div>
                            <div class="price_text ">
                                <div class="price_dish ">
                                    <p>Название Блюда : <?php echo e($menu->name); ?></p>
                                    <p>Цена : <?php echo e($menu->price); ?></p>
                                </div>
                                <p class="price_dish_text "><?php echo e($menu->desc); ?></p>
                            </div>
                            <div class="price_icon ">
                                <i class="fa fa-ban "></i>
                                <!-- <img src="images/Group-1260.png "> -->
                                <img src="<?php echo e(asset('assets/images/Group_1134.png')); ?> ">
                                <img src="<?php echo e(asset('assets/images/Group-139.png ')); ?>" onclick="deleteFunc('<?php echo e($menu->id); ?>')">
                            </div>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('assets/js/accardion.js')); ?>"></script>
    <script src="/js/app.js"></script>
    <script type="text/javascript">
        $(document).ready( function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $('#ajax-crud-datatable').DataTable({
                processing: true,
                serverSide: true,
                language: {
                    "sProcessing":   "Подождите...",
	"sLengthMenu":   "Показать _MENU_ записей",
	"sZeroRecords":  "Записи отсутствуют.",
	"sInfo":         "Записи с _START_ до _END_ из _TOTAL_ записей",
	"sInfoEmpty":    "Записи с 0 до 0 из 0 записей",
	"sInfoFiltered": "(отфильтровано из _MAX_ записей)",
	"sInfoPostFix":  "",
	"sSearch":       "Поиск:",
	"sUrl":          "",
	"oPaginate": {
		"sFirst": "Первая",
		"sPrevious": "Предыдущая",
		"sNext": "Следующая",
		"sLast": "Последняя"
	},
	"oAria": {
		"sSortAscending":  ": активировать для сортировки столбца по возрастанию",
		"sSortDescending": ": активировать для сортировки столбцов по убыванию"
	}
                 },
                ajax: "<?php echo e(route('restMenu',request()->route('id') )); ?>",
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'name', name: 'name' },
                    { data: 'price', name: 'price' },
                    { data: 'category.name', name: 'category_id' },
                    { data: 'img', render : function ( data, type, row, meta ) {
                            let img = `<img src="/get_file?path=${data}" width="50">`
                            return img
                        } },
                    {data: "id" , render : function ( data, type, row, meta ) {
                            let but = `<div>
                            <button class="btn" onclick="deleteFunc5('${data}')">
                            <i class="fa fa-trash" aria-hidden="true"></i>
                            </button>
                            <a class="btn" href="<?php echo e(url('restaurant/menu/edit')); ?>/${data}">
                            <i class="fas fa-edit"></i>
                            </a>
                            </div>`
                            return but
                        }},
                ],
                order: [[0, 'desc']]
            });
        });
        function add(){
            $('#CompanyForm').trigger("reset");
            $('#CompanyModal').html("Добавить блюда");
            $('#company-modal').modal('show');
            $('#id').val('');
        }
        function editFunc(id){
            $.ajax({
                type:"POST",
                url: "",
                data: { id: id },
                dataType: 'json',
                success: function(res){
                    $('#CompanyModal').html("Edit Company");
                    $('#company-modal').modal('show');
                    $('#id').val(res.id);
                    $('#name').val(res.name);
                    $('#address').val(res.address);
                    $('#email').val(res.email);
                }
            });
        }
        function deleteFunc(id){

                $.ajax({
                    type:"DELETE",
                    url: "<?php echo e(url('restaurant/menu/delete')); ?>/" + id ,
                    data: { id: id },
                    dataType: 'json',
                    success: function(res){
                        var oTable = $('#ajax-crud-datatable').dataTable();
                        oTable.fnDraw(false);
                    }
                });

        }
        $('#CompanyForm').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                type:'POST',
                url: "<?php echo e(route('restMenuCreate',request()->route('id'))); ?>",
                data: formData,
                cache:false,
                contentType: false,
                processData: false,
                success: (data) => {
                    $("#company-modal").modal('hide');
                    var oTable = $('#ajax-crud-datatable').dataTable();
                    oTable.fnDraw(false);
                    $("#btn-save").html('Submit');
                    $("#btn-save"). attr("disabled", false);
                },
                error: function(data){
                    console.log(data);
                }
            });
        });

    </script>
    <script>

        //karine
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB Programms\htdocs\narek\BronRest\resources\views/restaurant/menu/index.blade.php ENDPATH**/ ?>